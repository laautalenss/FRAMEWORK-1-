<?php

class Usuario extends Base
{
    function __construct()
    {
        $this->tabla = 'usuarios';
    }


}