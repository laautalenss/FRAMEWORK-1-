<?php

class CalendarioController
{
    public static function pintar()
    {
        require_once "bbdd/bbdd.php"; // conexión PDO

        $db = $baseDatos::connect();

        $sql = "
        SELECT 
            h.dia,
            h.hora_inicio,
            h.hora_fin,
            m.nombre AS nombre_modulo,
            m.siglas AS siglas_modulo,
            m.color AS color_modulo,
            CONCAT(p.nombre, ' ', p.apellidos) AS nombre_profesor,
            c.curso_numero,
            c.nombre_grado,
            c.letra
        FROM 
            horarios h
            JOIN modulos m ON h.id_modulo = m.id
            JOIN personas p ON h.id_profesor = p.id
            JOIN cursos c ON m.curso_asignado = c.id
        ORDER BY 
            h.dia, h.hora_inicio;
        ";

        $stmt = $db->query($sql);
        $horario = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Pasar datos a la vista
        require "views/horario/index.php";
    }
}
