<?php

class CalendarioController
{
    public static function pintar() {}
}
