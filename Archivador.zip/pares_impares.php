#!/usr/bin/php
<?php


    $cadena = "Programar en PHP es divertido";
    $vocales = "aeiou";


    $cadena_aux = strtolower($cadena);


    echo $cadena_aux;
