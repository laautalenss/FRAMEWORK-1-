<?php
    header('Content-Type: text/plain');
    echo "Hola desde el servidor sin JSON. Fecha: " . date('Y-m-d H:i:s');
?>